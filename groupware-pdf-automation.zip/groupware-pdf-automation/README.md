# 그룹웨어 문서 PDF 다운로드 자동화

사내 그룹웨어(전자결재 시스템)에서 특정 양식(출장신청서, 출장보고서 등)의 문서를
목록에서 한 건씩 자동으로 열어 PDF로 저장해주는 Selenium 기반 자동화 도구입니다.

> ⚠️ 이 코드는 특정 그룹웨어(더존 Bizbox 계열)의 화면 구조에 맞춰 작성되었습니다.
> 다른 그룹웨어를 쓰신다면 화면 구조가 달라 selector(요소 선택자) 수정이 필요할 수 있습니다.

## 포함된 스크립트 (3종)

| 파일 | 용도 |
|---|---|
| `scripts/download_travel_application.py` | 목록에서 "출장신청서" 양식 문서를 찾아 PDF로 자동 다운로드 |
| `scripts/download_travel_report.py` | 목록에서 "출장보고서" 양식 문서를 찾아 PDF로 자동 다운로드 |
| `scripts/compare_missing_documents.py` | 내가 가진 전체 대상 목록(xlsx)과, 위 자동화가 만든 완료목록(csv)을 대조해서 아직 못 받은 문서를 뽑아냄 |

자세한 사용법은 [`docs/USAGE.md`](docs/USAGE.md) 를 참고해주세요. (프로그래밍을 모르셔도 따라할 수 있도록 작성했습니다.)

## 요구 사항

- Windows 10/11 (Mac에서도 동작하나, 아래 안내는 Windows 기준입니다)
- Python 3.9 이상
- Google Chrome 브라우저

## 빠른 시작

```bash
pip install selenium pandas openpyxl
```

각 스크립트 상단의 `설정값` 부분(특히 `GROUPWARE_URL`)을 본인의 그룹웨어 주소로 수정한 뒤 실행하세요.

```bash
python scripts/download_travel_application.py
```

## 커스터마이징이 필요한 설정값

### `download_travel_application.py`, `download_travel_report.py` 공통

| 변수명 | 기본값 | 설명 |
|---|---|---|
| `GROUPWARE_URL` | `https://your-groupware-url.example.com` | **필수 수정.** 본인 그룹웨어 로그인 페이지 주소 |
| `TARGET_FORM_NAME` | `"출장신청서"` / `"출장보고서"` | 목록에서 필터링할 양식명. 다른 양식을 받고 싶다면 이 값을 바꾸면 됨 |
| `WAIT_SECONDS` | `15` | 요소가 나타날 때까지 최대로 기다리는 시간(초). 사이트가 느리면 늘리기 |
| `IFRAME_SELECTOR` | `iframe[name='_content']` | 목록이 iframe 안에 있는 경우의 iframe selector. 그룹웨어 화면 구조에 따라 다를 수 있음 (`docs/USAGE.md` 3-2 참고) |
| `get_rows()` 내부 selector | `div.grid-content table tbody tr` | 문서 목록 표의 각 행을 찾는 selector |
| `row_info()` 내부 인덱스 | `cells[2]`, `cells[4]`, `cells[5]` | 표에서 등록번호/양식명/제목이 위치한 컬럼 순서 |
| PDF 저장 버튼 selector | `input[value='PDF저장']` | 팝업 안 PDF 저장 버튼 |
| 다음 페이지 버튼 selector | `span.nex` | 페이지네이션 "다음" 버튼 |

`DOWNLOAD_DIR`, `LOG_CSV`는 `TARGET_FORM_NAME` 기준으로 자동 결정되므로 직접 수정할 필요는 없습니다.

### `compare_missing_documents.py`

| 변수명 | 기본값 | 설명 |
|---|---|---|
| `XLSX_PATH` | `전체목록.xlsx` (스크립트와 같은 폴더 기준) | **필수 수정.** 본인이 가진 전체 대상 목록 엑셀 파일 경로 |
| `XLSX_TITLE_COLUMN` | `"신청내역"` | 그 엑셀에서 문서제목이 들어있는 컬럼명 |
| `CSV_PATHS` | `["완료목록.csv"]` | 다운로드 스크립트가 만든 완료목록.csv 경로들 (여러 개 나열 가능) |
| `CSV_AUTO_SEARCH_ROOT` | `None` | 지정하면 이 폴더 하위의 모든 `완료목록.csv`를 자동으로 찾아 합침 (`CSV_PATHS`를 빈 리스트로 둬야 적용됨) |
| `OUTPUT_PATH` | `미확보목록.xlsx` | 결과 파일 저장 경로 |
| `SIMILARITY_THRESHOLD` | `0.85` | 이 값 이상 유사하면 "유사매칭"으로 분류 (0~1, 1에 가까울수록 엄격) |

selector 값을 어떻게 확인하고 수정하는지는 `docs/USAGE.md`의 "3-2. 화면 구조(selector) 확인" 항목에 개발자도구 사용법과 함께 자세히 안내되어 있습니다.

## 주의사항 / 면책

- 이 코드는 **본인 소속 기관의 정당한 업무 목적**(본인이 열람 권한을 가진 문서를 다운로드)으로만 사용해야 합니다.
- 그룹웨어 로그인 정보(아이디/비밀번호)는 코드에 저장하지 않으며, 실행 시 브라우저에서 직접 로그인하는 방식입니다.
- 반복적인 자동 요청이 서버에 부담을 줄 수 있으니, 짧은 기간에 대량으로 돌리기보다는 날짜 범위를 나눠서 실행하는 것을 권장합니다.
- 그룹웨어 화면 구조는 회사/버전마다 다르므로, 본인의 그룹웨어에 맞게 selector를 직접 확인하고 수정해야 합니다. (`docs/USAGE.md`의 "다른 그룹웨어에 맞게 수정하는 법" 참고)
- 이 저장소는 특정 회사 내부 시스템의 실제 주소를 포함하지 않습니다. 사용 전 본인 환경의 주소로 반드시 채워 넣어야 동작합니다.

## 라이선스

MIT License — 자유롭게 가져다 쓰시되, 무보증(as-is)입니다.
