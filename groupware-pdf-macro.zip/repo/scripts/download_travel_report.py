# -*- coding: utf-8 -*-
"""
출장신청서 문서 PDF 자동 다운로드 매크로 (Selenium)

사용 전 준비:
1. pip install selenium
2. Chrome 브라우저가 PC에 설치되어 있어야 합니다.
   (selenium 4.6 이상은 크롬드라이버를 자동으로 관리해줍니다. 별도 설치 불필요)

동작 흐름:
1. 그룹웨어 로그인 페이지를 열고, 사용자가 직접 로그인 + 검색 조건 입력
2. 콘솔에서 Enter를 누르면 자동 진행 시작
3. 목록 페이지의 각 행을 순회하며 "출장신청서" 양식만 필터링
4. 행 클릭 -> 팝업 열림 -> PDF 저장 버튼 클릭 -> 다운로드
5. 팝업 닫고 다음 행으로, 페이지 끝나면 AJAX로 다음 페이지 이동
6. 처리한 문서번호는 CSV에 기록해서 재실행 시 중복 방지
"""

import csv
import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# ------------------- 설정값 -------------------
GROUPWARE_URL = "https://your-groupware-url.example.com"  # ★ 사용자의 그룹웨어 주소로 반드시 교체하세요

TARGET_FORM_NAME = "출장보고서"  # 필터링할 양식명
WAIT_SECONDS = 15  # 요소 대기 최대 시간

DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", f"{TARGET_FORM_NAME}_PDF")
LOG_CSV = os.path.join(DOWNLOAD_DIR, "완료목록.csv")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)


def get_driver():
    options = webdriver.ChromeOptions()
    prefs = {
        "download.default_directory": DOWNLOAD_DIR,
        "download.prompt_for_download": False,
        "plugins.always_open_pdf_externally": True,
    }
    options.add_experimental_option("prefs", prefs)
    driver = webdriver.Chrome(options=options)
    driver.maximize_window()
    return driver


def load_done_list():
    done = set()
    if LOG_CSV and os.path.exists(LOG_CSV):
        with open(LOG_CSV, newline="", encoding="utf-8-sig") as f:
            for row in csv.reader(f):
                if row:
                    done.add(row[0])
    return done


def append_done(doc_no, title):
    with open(LOG_CSV, "a", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerow([doc_no, title, time.strftime("%Y-%m-%d %H:%M:%S")])


def wait_click(driver, by, selector, timeout=WAIT_SECONDS):
    el = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((by, selector))
    )
    el.click()
    return el


IFRAME_SELECTOR = (By.CSS_SELECTOR, "iframe[name='_content']")


def switch_to_content_frame(driver):
    """목록이 들어있는 iframe(_content) 안으로 전환한다."""
    driver.switch_to.default_content()
    WebDriverWait(driver, WAIT_SECONDS).until(
        EC.frame_to_be_available_and_switch_to_it(IFRAME_SELECTOR)
    )


def get_rows(driver):
    return driver.find_elements(By.CSS_SELECTOR, "div.grid-content table tbody tr")


def row_info(row):
    cells = row.find_elements(By.TAG_NAME, "td")
    return {
        "doc_no": cells[2].text.strip(),      # 등록번호 (예: 경영기획부-24)
        "form_name": cells[4].text.strip(),   # 양식명 (예: 출장신청서)
        "title": cells[5].text.strip(),       # 제목
    }


def open_popup_and_save_pdf(driver, row):
    main_handle = driver.current_window_handle
    before_handles = set(driver.window_handles)

    title_span = row.find_element(
        By.CSS_SELECTOR, "td:nth-child(6) span[onclick*='titleOnClickPudd']"
    )
    title_span.click()

    WebDriverWait(driver, WAIT_SECONDS).until(
        lambda d: len(d.window_handles) > len(before_handles)
    )
    new_handle = (set(driver.window_handles) - before_handles).pop()
    driver.switch_to.window(new_handle)

    # 팝업 문서 로딩이 끝날 때까지 대기
    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
    except TimeoutException:
        pass

    try:
        pdf_btn = WebDriverWait(driver, WAIT_SECONDS).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "input[value='PDF저장']"))
        )
        # 로딩/딤 처리 오버레이가 사라질 때까지 잠시 대기
        try:
            WebDriverWait(driver, 5).until(
                EC.invisibility_of_element_located(
                    (By.CSS_SELECTOR, "div[style*='z-index: 2002']")
                )
            )
        except TimeoutException:
            pass

        try:
            pdf_btn.click()
        except Exception:
            # 여전히 다른 요소가 클릭을 가로챈다면 JS로 강제 클릭
            driver.execute_script("arguments[0].click();", pdf_btn)

        # 다운로드 완료 대기 (간단 버전: 고정 대기)
        # 더 견고하게 하려면 DOWNLOAD_DIR을 폴링해서 .crdownload가 사라질 때까지 대기하는 함수로 교체 권장
        time.sleep(3)
    finally:
        driver.close()
        driver.switch_to.window(main_handle)
        # 창 전환 시 iframe 컨텍스트가 초기화되므로 다시 진입
        switch_to_content_frame(driver)


def go_next_page(driver):
    try:
        next_span = driver.find_element(By.CSS_SELECTOR, "span.nex")
    except NoSuchElementException:
        return False

    if "disabled" in (next_span.get_attribute("class") or ""):
        return False

    old_rows = get_rows(driver)
    reference_row = old_rows[0] if old_rows else None

    next_span.find_element(By.TAG_NAME, "a").click()

    if reference_row is not None:
        try:
            WebDriverWait(driver, WAIT_SECONDS).until(EC.staleness_of(reference_row))
        except TimeoutException:
            pass

    try:
        WebDriverWait(driver, WAIT_SECONDS).until(
            EC.invisibility_of_element_located(
                (By.CSS_SELECTOR, "div.PUDD-UI-loading")
            )
        )
    except TimeoutException:
        pass

    return True


def main():
    driver = get_driver()
    done = load_done_list()

    driver.get(GROUPWARE_URL)
    input(
        "브라우저에서 로그인을 완료하고, 등록일자/부서 등 검색 조건까지 입력해 "
        "검색 버튼을 누른 뒤 여기로 돌아와 Enter를 누르세요: "
    )

    print(f"[안내] 다운로드 폴더: {DOWNLOAD_DIR}")
    switch_to_content_frame(driver)

    page = 1
    while True:
        print(f"--- {page} 페이지 처리 중 ---")
        rows = get_rows(driver)
        print(f"[디버그] 찾은 행 개수: {len(rows)}")
        skipped_form_mismatch = 0
        if len(rows) == 0:
            # 원인 파악용: 현재 페이지에 grid-content가 있는지, table이 몇 개인지 확인
            grids = driver.find_elements(By.CSS_SELECTOR, "div.grid-content")
            tables = driver.find_elements(By.TAG_NAME, "table")
            print(f"[디버그] div.grid-content 개수: {len(grids)}, table 태그 개수: {len(tables)}")
            for i, t in enumerate(tables):
                print(f"[디버그] table[{i}] class={t.get_attribute('class')!r} id={t.get_attribute('id')!r}")
        for row in rows:
            try:
                info = row_info(row)
            except Exception:
                continue  # 헤더 행 등 td가 부족한 행은 건너뜀

            if info["form_name"] != TARGET_FORM_NAME:
                skipped_form_mismatch += 1
                if skipped_form_mismatch <= 3:
                    print(f"[디버그] 양식명 불일치로 건너뜀: '{info['form_name']}' (기대값: '{TARGET_FORM_NAME}')")
                continue
            if info["doc_no"] in done:
                print(f"이미 처리됨, 건너뜀: {info['doc_no']}")
                continue
            try:
                open_popup_and_save_pdf(driver, row)
                append_done(info["doc_no"], info["title"])
                done.add(info["doc_no"])
                print(f"완료: {info['doc_no']} - {info['title']}")
            except TimeoutException:
                print(f"실패(타임아웃): {info['doc_no']} - {info['title']}")
            except Exception as e:
                print(f"실패: {info['doc_no']} - {e}")
            time.sleep(1)  # 서버 부하 방지용 딜레이

        if not go_next_page(driver):
            print("마지막 페이지입니다. 종료합니다.")
            break
        page += 1

    driver.quit()
    print(f"완료된 목록은 {LOG_CSV} 에서 확인할 수 있습니다.")


if __name__ == "__main__":
    main()
