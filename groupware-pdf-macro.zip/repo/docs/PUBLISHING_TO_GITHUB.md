# GitHub에 공유하는 방법 (비개발자용, 명령어 없이 웹 화면만으로)

git 명령어를 몰라도 웹 브라우저만으로 전부 가능합니다.

---

## 1단계. GitHub 계정 만들기
1. https://github.com 접속 → 우측 상단 "Sign up"
2. 이메일, 비밀번호, 아이디 입력해서 가입 (무료)

## 2단계. 새 저장소(Repository) 만들기
1. 로그인 후 우측 상단 **"+"** 버튼 → **"New repository"**
2. **Repository name**: 예) `groupware-pdf-macro`
3. **Description**(선택): "그룹웨어 문서 PDF 자동 다운로드 매크로"
4. **Public / Private** 선택
   - **Public**: 누구나 볼 수 있음 (공유가 목적이면 이걸 선택)
   - **Private**: 초대한 사람만 볼 수 있음
   - ⚠️ Public으로 할 경우, 코드 안에 회사 내부 주소나 개인정보가 없는지 **반드시 한 번 더 확인**하세요. (아래 "공개 전 체크리스트" 참고)
5. **"Add a README file"** 체크 (일단 체크해도 되고, 이미 README.md를 따로 준비했다면 안 해도 됨)
6. **"Create repository"** 클릭

## 3단계. 파일 업로드 (드래그 앤 드롭으로 가능)
1. 방금 만든 저장소 페이지에서 **"Add file"** 버튼 → **"Upload files"** 클릭
2. 아래 폴더 구조를 파일 탐색기에서 그대로 이 화면으로 **드래그해서 끌어다 놓기**:
   ```
   groupware-pdf-macro/
   ├── README.md
   ├── docs/
   │   ├── USAGE.md
   │   └── PUBLISHING_TO_GITHUB.md   (본인만 참고할 문서라 안 올려도 무방)
   └── scripts/
       ├── download_travel_application.py
       ├── download_travel_report.py
       └── compare_missing_documents.py
   ```
   - 폴더째 끌어다 놓아도 GitHub가 폴더 구조를 그대로 인식합니다.
3. 화면 하단 **"Commit changes"** 버튼 클릭 (설명 문구는 기본값 그대로 둬도 됩니다)

이제 저장소 주소(`https://github.com/내아이디/groupware-pdf-macro`)를 공유하면, 사람들이 "Code → Download ZIP"으로 내려받아 쓸 수 있습니다.

## 4단계. README가 잘 보이는지 확인
저장소 메인 페이지에 접속하면 `README.md` 내용이 자동으로 화면에 표시됩니다. 잘 안 보이면 파일명이 정확히 `README.md`(대소문자 포함)인지 확인하세요.

## 5단계. 나중에 파일을 수정하고 싶을 때
1. 저장소에서 수정할 파일 클릭
2. 오른쪽 위 **연필 아이콘(Edit)** 클릭
3. 내용 수정 후 하단 **"Commit changes"**

또는 파일을 통째로 교체하고 싶으면, 기존 파일을 삭제(휴지통 아이콘)하고 2-3단계처럼 새로 업로드하면 됩니다.

---

## 공개(Public) 전 체크리스트

- [ ] `GROUPWARE_URL`이 실제 기관 주소가 아니라 예시 주소(`https://your-groupware-url.example.com`)로 되어 있는지
- [ ] 아이디/비밀번호, 인증 토큰 등이 코드 어디에도 하드코딩되어 있지 않은지
- [ ] 다운로드된 실제 PDF, 완료목록.csv, 개인정보가 담긴 xlsx 등 **결과물 파일은 업로드하지 않았는지**
- [ ] 사람 이름, 부서명 등이 "예시"로만 쓰였는지 (README/USAGE의 예시 문구 정도는 무방하나, 실제 문서 내용을 캡쳐한 이미지 등은 올리지 않는 것을 권장)

특히 이 프로젝트를 소속 기관 이름으로 공개하실 거라면, 공개 전에 팀 내부적으로 "이 정도 정보 공개해도 괜찮은지" 한 번 확인받으시는 걸 권장드려요.
